package com.gocartacho.gocartacho.model;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "Afluencia_Historica")
public class AfluenciaHistorica implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hist_id")
    private Long histId; // Usamos Long por si crece mucho

    @Enumerated(EnumType.STRING)
    @Column(name = "dia_semana", nullable = false)
    private DiaSemana diaSemana;

    @Column(name = "hora", nullable = false)
    private Integer hora; // Formato 0-23

    @Enumerated(EnumType.STRING)
    @Column(name = "nivel_promedio", nullable = false)
    private NivelAfluencia nivelPromedio;

    // --- Relación con Zona ---
    // Muchos registros históricos pueden pertenecer a Una Zona
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "zona_id", nullable = false)
    private Zona zona;

    public Long getHistId() {
        return histId;
    }

    public void setHistId(Long histId) {
        this.histId = histId;
    }

    public DiaSemana getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(DiaSemana diaSemana) {
        this.diaSemana = diaSemana;
    }

    public Integer getHora() {
        return hora;
    }

    public void setHora(Integer hora) {
        this.hora = hora;
    }

    public NivelAfluencia getNivelPromedio() {
        return nivelPromedio;
    }

    public void setNivelPromedio(NivelAfluencia nivelPromedio) {
        this.nivelPromedio = nivelPromedio;
    }

    public Zona getZona() {
        return zona;
    }

    public void setZona(Zona zona) {
        this.zona = zona;
    }
}