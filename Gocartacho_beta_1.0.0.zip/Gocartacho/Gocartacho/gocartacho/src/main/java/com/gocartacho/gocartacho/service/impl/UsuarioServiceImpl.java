package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.model.Usuario;
import com.gocartacho.gocartacho.repository.UsuarioRepository;
import com.gocartacho.gocartacho.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Override
    public Usuario registrarUsuario(Usuario usuario) throws Exception {
        if (usuarioRepository.findByEmail(usuario.getEmail()).isPresent()) {
            throw new Exception("El email '" + usuario.getEmail() + "' ya está registrado.");
        }
        return usuarioRepository.save(usuario);
    }

    @Override
    public Optional<Usuario> obtenerUsuarioPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    @Override
    public Usuario autenticarUsuario(String email, String contrasena) throws Exception {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByEmail(email);
        
        if (usuarioOpt.isEmpty()) {
            throw new Exception("Usuario no encontrado.");
        }

        Usuario usuario = usuarioOpt.get();
        
        // Comparación simple de contraseña (texto plano)
        if (!usuario.getContrasena().equals(contrasena)) {
            throw new Exception("Contraseña incorrecta.");
        }

        return usuario;
    }

    // NUEVO: Implementación del conteo
    @Override
    public long contarUsuarios() {
        return usuarioRepository.count();
    }
}