package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.dto.LoginRequest;
import com.gocartacho.gocartacho.model.Usuario;
import com.gocartacho.gocartacho.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/register")
    public ResponseEntity<?> registrarUsuario(@RequestBody Usuario usuario) {
        try {
            Usuario usuarioRegistrado = usuarioService.registrarUsuario(usuario);
            // Por seguridad, no devolvemos la contraseña en la respuesta
            usuarioRegistrado.setContrasena(null); 
            return ResponseEntity.ok(usuarioRegistrado);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        try {
            // 1. Autenticación Real: Busca en la Base de Datos por email y contraseña
            Usuario usuario = usuarioService.autenticarUsuario(loginRequest.getEmail(), loginRequest.getContrasena());
            
            // 2. Seguridad: Limpiamos la contraseña antes de enviar el objeto al frontend
            usuario.setContrasena(null);
            
            // 3. Respuesta: Se devuelve el objeto Usuario completo (incluyendo el campo 'rol' que viene de la BD)
            return ResponseEntity.ok(usuario); 
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}