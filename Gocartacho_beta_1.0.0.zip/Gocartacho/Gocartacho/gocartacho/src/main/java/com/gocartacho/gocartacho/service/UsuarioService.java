package com.gocartacho.gocartacho.service;

import com.gocartacho.gocartacho.model.Usuario;
import java.util.Optional;

public interface UsuarioService {

    Usuario registrarUsuario(Usuario usuario) throws Exception;

    Optional<Usuario> obtenerUsuarioPorEmail(String email);
    
    Usuario autenticarUsuario(String email, String contrasena) throws Exception;

    // NUEVO: Método para saber cuántos usuarios hay en total en la BD
    long contarUsuarios();
}