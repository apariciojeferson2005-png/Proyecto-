package com.gocartacho.gocartacho.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "Zonas")
public class Zona implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "zona_id")
    private Integer zonaId;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "descripcion", columnDefinition = "TEXT")
    private String descripcion;
    
    // Coordenadas para el mapa
    @Column(name = "latitud", precision = 10, scale = 8)
    private BigDecimal latitud;

    @Column(name = "longitud", precision = 11, scale = 8)
    private BigDecimal longitud;
    
    // Dato calculado para el color del mapa (simulado)
    @Transient
    private Integer nivelConcurrencia = 5; 

    // --- RELACIONES ---
    
    @OneToMany(mappedBy = "zona", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore // ¡NECESARIO! Evita el bucle infinito al pintar el mapa
    private List<AfluenciaHistorica> afluencias;

    @OneToMany(mappedBy = "zona", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore // ¡NECESARIO! Evita el bucle infinito al pintar el mapa
    private Set<Comercio> comercios;

    // --- Getters y Setters ---
    public Integer getZonaId() { return zonaId; }
    public void setZonaId(Integer zonaId) { this.zonaId = zonaId; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getLatitud() { return latitud; }
    public void setLatitud(BigDecimal latitud) { this.latitud = latitud; }

    public BigDecimal getLongitud() { return longitud; }
    public void setLongitud(BigDecimal longitud) { this.longitud = longitud; }

    public Integer getNivelConcurrencia() { return nivelConcurrencia; }
    public void setNivelConcurrencia(Integer nivelConcurrencia) { this.nivelConcurrencia = nivelConcurrencia; }

    public Set<Comercio> getComercios() { return comercios; }
    public void setComercios(Set<Comercio> comercios) { this.comercios = comercios; }

    public List<AfluenciaHistorica> getAfluencias() { return afluencias; }
    public void setAfluencias(List<AfluenciaHistorica> afluencias) { this.afluencias = afluencias; }
}