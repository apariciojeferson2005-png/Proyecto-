package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.service.RutaService;
import com.gocartacho.gocartacho.service.UsuarioService;
import com.gocartacho.gocartacho.service.ZonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.Collections;

@Controller 
public class WebController {

    @Autowired
    private ZonaService zonaService;

    @Autowired
    private RutaService rutaService;

    @Autowired
    private UsuarioService usuarioService; 

    // 1. Página de Inicio (Mapa)
    @GetMapping("/")
    public String index(Model model) {
        try {
            model.addAttribute("zonas", zonaService.obtenerTodasLasZonas());
        } catch (Exception e) {
            System.err.println("Error cargando zonas: " + e.getMessage());
            model.addAttribute("zonas", Collections.emptyList());
        }
        return "index"; 
    }

    // 2. Página de Rutas
    @GetMapping("/rutas")
    public String rutas(Model model) {
        try {
            model.addAttribute("rutas", rutaService.obtenerTodasLasRutas());
        } catch (Exception e) {
            model.addAttribute("rutas", Collections.emptyList());
        }
        return "rutas"; 
    }

    // 3. Página de Login
    @GetMapping("/login")
    public String login() {
        return "login"; 
    }

    // 4. Página de Registro
    @GetMapping("/register")
    public String register() {
        return "register"; 
    }

    // 5. RUTA DASHBOARD ADMIN
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        // Cargar zonas para el mapa de fondo
        try {
            model.addAttribute("zonas", zonaService.obtenerTodasLasZonas());
        } catch (Exception e) {
            model.addAttribute("zonas", Collections.emptyList());
        }
        
        // Cargar conteo de usuarios (Ahora sí funcionará porque usuarioService está declarado arriba)
        long totalUsuarios = usuarioService.contarUsuarios();
        model.addAttribute("totalUsuarios", totalUsuarios);
        
        return "dashboard"; 
    }
}