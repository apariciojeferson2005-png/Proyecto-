package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.dto.ComercioDTO;
import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.Ruta;
import com.gocartacho.gocartacho.model.RutaComercio;
import com.gocartacho.gocartacho.repository.RutaComercioRepository;
import com.gocartacho.gocartacho.repository.RutaRepository;
import com.gocartacho.gocartacho.service.RutaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class RutaServiceImpl implements RutaService {

    @Autowired
    private RutaRepository rutaRepository;

    @Autowired
    private RutaComercioRepository rutaComercioRepository;

    @Override
    public List<Ruta> obtenerTodasLasRutas() {
        return rutaRepository.findAll();
    }

    @Override
    public List<ComercioDTO> obtenerComerciosPorRuta(Integer rutaId) {
        Ruta ruta = rutaRepository.findById(rutaId).orElse(null);
        if (ruta == null) {
            return Collections.emptyList();
        }

        // 1. Obtiene la lista de uniones ordenadas
        List<RutaComercio> uniones = rutaComercioRepository.findByRutaOrderByOrdenAsc(ruta);

        // 2. Transforma a DTO para evitar errores de JSON y agregar datos extra
        return uniones.stream()
                .map(union -> {
                    Comercio c = union.getComercio();
                    // Simulamos usuarios entre 0 y 20 para el demo
                    int usuariosRandom = ThreadLocalRandom.current().nextInt(0, 21);
                    
                    return new ComercioDTO(
                        c.getComercioId(),
                        c.getNombre(),
                        c.getTipoNegocio().toString(),
                        usuariosRandom
                    );
                })
                .collect(Collectors.toList());
    }
}