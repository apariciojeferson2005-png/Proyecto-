package com.gocartacho.gocartacho.dto;

public class ComercioDTO {
    private Integer id;
    private String nombre;
    private String tipoNegocio;
    private int usuariosActuales; // Nuevo campo para mostrar gente en el sitio

    public ComercioDTO(Integer id, String nombre, String tipoNegocio, int usuariosActuales) {
        this.id = id;
        this.nombre = nombre;
        this.tipoNegocio = tipoNegocio;
        this.usuariosActuales = usuariosActuales;
    }

    // Getters y Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTipoNegocio() { return tipoNegocio; }
    public void setTipoNegocio(String tipoNegocio) { this.tipoNegocio = tipoNegocio; }
    public int getUsuariosActuales() { return usuariosActuales; }
    public void setUsuariosActuales(int usuariosActuales) { this.usuariosActuales = usuariosActuales; }
}