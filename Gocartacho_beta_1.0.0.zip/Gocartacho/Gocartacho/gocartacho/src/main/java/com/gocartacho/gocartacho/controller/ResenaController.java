package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.dto.ResenaRequest;
import com.gocartacho.gocartacho.model.Resena;
import com.gocartacho.gocartacho.service.ResenaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class ResenaController {

    @Autowired
    private ResenaService resenaService;

    /**
     * Endpoint para obtener todas las reseñas de un comercio.
     * URL: GET /api/v1/comercios/42/resenas
     */
    @GetMapping("/comercios/{comercioId}/resenas")
    public ResponseEntity<List<Resena>> obtenerResenasDeComercio(@PathVariable Integer comercioId) {
        List<Resena> resenas = resenaService.obtenerResenasPorComercio(comercioId);
        return ResponseEntity.ok(resenas);
    }

    /**
     * Endpoint para publicar una nueva reseña.
     * URL: POST /api/v1/resenas
     */
    @PostMapping("/resenas")
    public ResponseEntity<?> publicarResena(@RequestBody ResenaRequest request) {
        try {
            Resena nuevaResena = resenaService.guardarResena(request);
            return ResponseEntity.ok(nuevaResena);
        } catch (Exception e) {
            // Si el usuario o comercio no existen, devuelve 400 Bad Request
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}