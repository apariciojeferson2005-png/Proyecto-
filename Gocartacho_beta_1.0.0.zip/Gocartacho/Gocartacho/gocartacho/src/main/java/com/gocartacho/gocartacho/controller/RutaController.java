package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.dto.ComercioDTO;
import com.gocartacho.gocartacho.model.Ruta;
import com.gocartacho.gocartacho.service.RutaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/rutas")
public class RutaController {

    @Autowired
    private RutaService rutaService;

    @GetMapping
    public ResponseEntity<List<Ruta>> obtenerTodasLasRutas() {
        return ResponseEntity.ok(rutaService.obtenerTodasLasRutas());
    }

    /**
     * Devuelve DTOs limpios con conteo de usuarios.
     */
    @GetMapping("/{rutaId}/comercios")
    public ResponseEntity<List<ComercioDTO>> obtenerComerciosDeRuta(@PathVariable Integer rutaId) {
        List<ComercioDTO> comercios = rutaService.obtenerComerciosPorRuta(rutaId);
        return ResponseEntity.ok(comercios);
    }
}