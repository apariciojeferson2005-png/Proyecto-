package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.TipoNegocio;
import com.gocartacho.gocartacho.model.Zona;
import com.gocartacho.gocartacho.repository.ComercioRepository;
import com.gocartacho.gocartacho.repository.ZonaRepository;
import com.gocartacho.gocartacho.service.ComercioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class ComercioServiceImpl implements ComercioService {

    @Autowired
    private ComercioRepository comercioRepository;
    
    @Autowired
    private ZonaRepository zonaRepository; // Necesitamos este para buscar la zona por ID

    @Override
    public List<Comercio> obtenerTodosLosComercios() {
        return comercioRepository.findAll();
    }

    @Override
    public Comercio obtenerComercioPorId(Integer id) {
        return comercioRepository.findById(id).orElse(null);
    }

    @Override
    public Comercio guardarComercio(Comercio comercio) {
        // Aquí podrías añadir lógica, ej: validar que la zona exista
        return comercioRepository.save(comercio);
    }

    @Override
    public List<Comercio> obtenerComerciosPorZona(Integer zonaId) {
        Optional<Zona> zona = zonaRepository.findById(zonaId);
        
        // Si la zona existe, busca los comercios. Si no, devuelve una lista vacía.
        return zona.map(comercioRepository::findByZona).orElse(Collections.emptyList());
    }

    @Override
    public List<Comercio> obtenerComerciosPorZonaYTipo(Integer zonaId, TipoNegocio tipo) {
        Optional<Zona> zona = zonaRepository.findById(zonaId);
        
        return zona.map(z -> comercioRepository.findByZonaAndTipoNegocio(z, tipo))
                   .orElse(Collections.emptyList());
    }
}