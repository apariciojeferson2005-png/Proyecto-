package com.gocartacho.gocartacho.repository;

import com.gocartacho.gocartacho.model.PuntoCalor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface PuntoCalorRepository extends JpaRepository<PuntoCalor, Long> {

    List<PuntoCalor> findByTimestampAfter(LocalDateTime timestamp);
}