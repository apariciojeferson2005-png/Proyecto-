package com.gocartacho.gocartacho.service;

import com.gocartacho.gocartacho.dto.ResenaRequest;
import com.gocartacho.gocartacho.model.Resena;
import java.util.List;

public interface ResenaService {
    
    /**
     * Guarda una nueva reseña usando los IDs del DTO.
     */
    Resena guardarResena(ResenaRequest request) throws Exception;
    
    /**
     * Obtiene todas las reseñas para un comercio específico.
     */
    List<Resena> obtenerResenasPorComercio(Integer comercioId);
}