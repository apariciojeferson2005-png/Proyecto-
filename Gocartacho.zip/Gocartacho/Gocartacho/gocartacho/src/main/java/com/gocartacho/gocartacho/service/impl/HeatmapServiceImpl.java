package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.dto.HeatmapPointDTO;
import com.gocartacho.gocartacho.model.*;
import com.gocartacho.gocartacho.repository.AfluenciaHistoricaRepository;
import com.gocartacho.gocartacho.repository.PuntoCalorRepository;
import com.gocartacho.gocartacho.repository.ZonaRepository;
import com.gocartacho.gocartacho.service.HeatmapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class HeatmapServiceImpl implements HeatmapService {

    @Autowired
    private PuntoCalorRepository puntoCalorRepository;

    @Autowired
    private AfluenciaHistoricaRepository afluenciaHistoricaRepository;

    @Autowired
    private ZonaRepository zonaRepository;

    @Override
    public void guardarPuntoCalor(PuntoCalor puntoCalor) {
        // Asignamos la fecha y hora actual del servidor antes de guardar
        puntoCalor.setTimestamp(LocalDateTime.now());
        puntoCalorRepository.save(puntoCalor);
    }

    @Override
    public List<HeatmapPointDTO> obtenerPuntosCalorTiempoReal() {
        // 1. Definir la ventana de "Tiempo Real"
        // Traemos todos los pings recibidos en los últimos 30 minutos.
        // Puedes ajustar este valor (ej: minusHours(1)) si quieres mostrar más historial.
        LocalDateTime ventanaTiempo = LocalDateTime.now().minusMinutes(30);

        // 2. Consultar la base de datos real
        // Usamos el método que ya tienes en tu repositorio para filtrar por fecha.
        List<PuntoCalor> puntosReales = puntoCalorRepository.findByTimestampAfter(ventanaTiempo);

        // 3. Transformar los datos de la Entidad (BD) al DTO (Mapa)
        List<HeatmapPointDTO> respuestaMapa = new ArrayList<>();

        for (PuntoCalor p : puntosReales) {
            // Validación simple para evitar errores si algún dato viene nulo
            if (p.getLatitud() != null && p.getLongitud() != null) {
                respuestaMapa.add(new HeatmapPointDTO(
                    p.getLatitud().doubleValue(),
                    p.getLongitud().doubleValue(),
                    1.0
                ));
            }
        }

        return respuestaMapa;
    }

    @Override
    public NivelAfluencia obtenerAfluenciaHistorica(Integer zonaId, DiaSemana dia, int hora) {
        Optional<Zona> zona = zonaRepository.findById(zonaId);

        if (zona.isPresent()) {
            Optional<AfluenciaHistorica> historico = afluenciaHistoricaRepository
                    .findByZonaAndDiaSemanaAndHora(zona.get(), dia, hora);

            return historico.map(AfluenciaHistorica::getNivelPromedio).orElse(NivelAfluencia.Bajo);
        }

        return NivelAfluencia.Bajo;
    }
}