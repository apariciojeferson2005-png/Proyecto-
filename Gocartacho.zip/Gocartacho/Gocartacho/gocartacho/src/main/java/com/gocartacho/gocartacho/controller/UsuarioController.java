package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.model.Usuario;
import com.gocartacho.gocartacho.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    /**
     * Endpoint para registrar un nuevo usuario.
     * URL: POST /api/v1/auth/register
     */
    @PostMapping("/register")
    public ResponseEntity<?> registrarUsuario(@RequestBody Usuario usuario) {
        try {
            Usuario usuarioRegistrado = usuarioService.registrarUsuario(usuario);
            // No devolvemos la contraseña en la respuesta
            usuarioRegistrado.setContrasena(null); 
            return ResponseEntity.ok(usuarioRegistrado);
        } catch (Exception e) {
            // Si el email ya existe, devuelve un error 400 Bad Request
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    // Aquí también iría un endpoint de "/login", pero requiere más
    // configuración de Spring Security (JWT) que podemos añadir después.
}