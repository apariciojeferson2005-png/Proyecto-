package com.gocartacho.gocartacho.service;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.TipoNegocio;
import java.util.List;

public interface ComercioService {
    
    List<Comercio> obtenerTodosLosComercios();
    
    Comercio obtenerComercioPorId(Integer id);
    
    Comercio guardarComercio(Comercio comercio);
    
    List<Comercio> obtenerComerciosPorZona(Integer zonaId);
    
    List<Comercio> obtenerComerciosPorZonaYTipo(Integer zonaId, TipoNegocio tipo);

    // --- NUEVO MÉTODO PARA FILTRO COMBINADO (TIPO + HORARIO) ---
    List<Comercio> obtenerComerciosFiltrados(Integer zonaId, TipoNegocio tipo, boolean soloAbiertos);
}