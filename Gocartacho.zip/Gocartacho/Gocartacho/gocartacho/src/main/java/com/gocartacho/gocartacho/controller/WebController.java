package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.service.ComercioService;
import com.gocartacho.gocartacho.service.ResenaService;
import com.gocartacho.gocartacho.service.RutaService;
import com.gocartacho.gocartacho.service.ZonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class WebController {

    // Inyección de todos los servicios necesarios
    @Autowired
    private ZonaService zonaService;

    @Autowired
    private RutaService rutaService;

    @Autowired
    private ComercioService comercioService;

    @Autowired
    private ResenaService resenaService;

    /**
     * 1. PÁGINA DE INICIO (MAPA)
     * Carga las zonas para que el mapa pueda pintarlas de colores (Rojo/Verde) según afluencia.
     */
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("zonas", zonaService.obtenerTodasLasZonas());
        return "index"; // Busca src/main/resources/templates/index.html
    }

    /**
     * 2. PÁGINA DE RUTAS SUGERIDAS
     * Muestra el listado de itinerarios turísticos.
     */
    @GetMapping("/rutas")
    public String rutas(Model model) {
        model.addAttribute("listaRutas", rutaService.obtenerTodasLasRutas());
        return "rutas"; // Busca src/main/resources/templates/rutas.html
    }

    /**
     * 3. PÁGINA DE DETALLE DEL COMERCIO
     * Muestra la información completa de un lugar y sus reseñas.
     */
    @GetMapping("/comercio/{id}")
    public String detalleComercio(@PathVariable Integer id, Model model) {
        // Buscamos el comercio por ID
        var comercio = comercioService.obtenerComercioPorId(id);
        
        // Si no existe, redirigimos al mapa para evitar errores
        if (comercio == null) {
            return "redirect:/"; 
        }

        // Buscamos las reseñas asociadas a este comercio
        var resenas = resenaService.obtenerResenasPorComercio(id);

        // Pasamos los datos a la vista (HTML)
        model.addAttribute("c", comercio);
        model.addAttribute("resenas", resenas);
        
        return "detalle"; // Busca src/main/resources/templates/detalle.html
    }

    /**
     * 4. PÁGINA DE LOGIN
     * Formulario para iniciar sesión.
     */
    @GetMapping("/login")
    public String login() {
        return "login"; // Busca src/main/resources/templates/login.html
    }

    /**
     * 5. PÁGINA DE REGISTRO
     * Formulario para crear una cuenta nueva.
     */
    @GetMapping("/registro")
    public String registro() {
        return "registro"; // Busca src/main/resources/templates/registro.html
    }
}