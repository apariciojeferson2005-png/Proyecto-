package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.TipoNegocio;
import com.gocartacho.gocartacho.model.Zona;
import com.gocartacho.gocartacho.repository.ComercioRepository;
import com.gocartacho.gocartacho.repository.ZonaRepository;
import com.gocartacho.gocartacho.service.ComercioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ComercioServiceImpl implements ComercioService {

    @Autowired
    private ComercioRepository comercioRepository;
    
    @Autowired
    private ZonaRepository zonaRepository;

    @Override
    public List<Comercio> obtenerTodosLosComercios() {
        return comercioRepository.findAll();
    }

    @Override
    public Comercio obtenerComercioPorId(Integer id) {
        return comercioRepository.findById(id).orElse(null);
    }

    @Override
    public Comercio guardarComercio(Comercio comercio) {
        return comercioRepository.save(comercio);
    }

    @Override
    public List<Comercio> obtenerComerciosPorZona(Integer zonaId) {
        Optional<Zona> zona = zonaRepository.findById(zonaId);
        return zona.map(comercioRepository::findByZonaOrderByVisitasMensualesDesc)
                   .orElse(Collections.emptyList());
    }

    @Override
    public List<Comercio> obtenerComerciosPorZonaYTipo(Integer zonaId, TipoNegocio tipo) {
        Optional<Zona> zona = zonaRepository.findById(zonaId);
        // Nota: Idealmente también deberíamos ordenar por visitas aquí, 
        // pero por ahora mantenemos la lógica base.
        return zona.map(z -> comercioRepository.findByZonaAndTipoNegocio(z, tipo))
                   .orElse(Collections.emptyList());
    }

    // --- NUEVA IMPLEMENTACIÓN DE FILTRADO AVANZADO ---
    @Override
    public List<Comercio> obtenerComerciosFiltrados(Integer zonaId, TipoNegocio tipo, boolean soloAbiertos) {
        // 1. Obtener la lista base de la zona (ordenada por popularidad)
        List<Comercio> comercios = obtenerComerciosPorZona(zonaId);

        // 2. Filtrar por Tipo (si se especificó)
        if (tipo != null) {
            comercios = comercios.stream()
                    .filter(c -> c.getTipoNegocio() == tipo)
                    .collect(Collectors.toList());
        }

        // 3. Filtrar por Horario (si se solicitó "solo abiertos")
        if (soloAbiertos) {
            LocalTime ahora = LocalTime.now();
            comercios = comercios.stream()
                    .filter(c -> estaAbierto(c, ahora))
                    .collect(Collectors.toList());
        }

        return comercios;
    }

    // Lógica auxiliar para calcular si está abierto
    private boolean estaAbierto(Comercio c, LocalTime horaActual) {
        if (c.getHorarioApertura() == null || c.getHorarioCierre() == null) return false;

        LocalTime apertura = c.getHorarioApertura();
        LocalTime cierre = c.getHorarioCierre();

        if (apertura.isBefore(cierre)) {
            // Caso normal (ej: 8am a 8pm)
            return horaActual.isAfter(apertura) && horaActual.isBefore(cierre);
        } else {
            // Caso nocturno que cruza medianoche (ej: 8pm a 3am)
            return horaActual.isAfter(apertura) || horaActual.isBefore(cierre);
        }
    }
}