package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.TipoNegocio;
import com.gocartacho.gocartacho.service.ComercioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/comercios")
public class ComercioController {

    @Autowired
    private ComercioService comercioService;

    /**
     * Endpoint PRINCIPAL para obtener comercios.
     * Soporta filtros por Tipo y por Estado (Abierto/Cerrado).
     * URL: GET /api/v1/comercios/zona/1?tipo=Restaurante&abierto=true
     */
    @GetMapping("/zona/{zonaId}")
    public ResponseEntity<List<Comercio>> obtenerComerciosPorZona(
            @PathVariable Integer zonaId,
            @RequestParam(required = false) TipoNegocio tipo,
            @RequestParam(required = false, defaultValue = "false") boolean abierto) {
        
        // Usamos el nuevo servicio inteligente
        List<Comercio> resultados = comercioService.obtenerComerciosFiltrados(zonaId, tipo, abierto);
        return ResponseEntity.ok(resultados);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Comercio> obtenerComercioPorId(@PathVariable Integer id) {
        Comercio comercio = comercioService.obtenerComercioPorId(id);
        if (comercio != null) {
            return ResponseEntity.ok(comercio);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}