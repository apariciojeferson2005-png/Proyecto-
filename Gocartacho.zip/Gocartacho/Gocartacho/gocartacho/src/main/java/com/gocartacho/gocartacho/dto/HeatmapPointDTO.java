package com.gocartacho.gocartacho.dto;

public class HeatmapPointDTO {
    private double lat;
    private double lng;
    private double intensity;

    public HeatmapPointDTO(double lat, double lng, double intensity) {
        this.lat = lat;
        this.lng = lng;
        this.intensity = intensity;
    }

    // Getters y Setters
    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public double getIntensity() {
        return intensity;
    }

    public void setIntensity(double intensity) {
        this.intensity = intensity;
    }
}
