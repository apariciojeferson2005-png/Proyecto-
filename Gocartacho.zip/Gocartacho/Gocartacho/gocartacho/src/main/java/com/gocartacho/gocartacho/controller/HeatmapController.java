package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.dto.HeatmapPointDTO;
import com.gocartacho.gocartacho.model.DiaSemana;
import com.gocartacho.gocartacho.model.NivelAfluencia;
import com.gocartacho.gocartacho.model.PuntoCalor;
import com.gocartacho.gocartacho.service.HeatmapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/heatmap") 
public class HeatmapController {

    @Autowired
    private HeatmapService heatmapService;

    
    @PostMapping("/ping")
    public ResponseEntity<Void> guardarPing(@RequestBody PuntoCalor puntoCalor) {
        heatmapService.guardarPuntoCalor(puntoCalor);
        return ResponseEntity.ok().build(); 
    }


    @GetMapping("/realtime")
    public ResponseEntity<List<HeatmapPointDTO>> obtenerPuntosTiempoReal() {
        List<HeatmapPointDTO> puntos = heatmapService.obtenerPuntosCalorTiempoReal();
        return ResponseEntity.ok(puntos); 
    }


    @GetMapping("/historical/{zonaId}")
    public ResponseEntity<NivelAfluencia> obtenerAfluenciaHistorica(
            @PathVariable Integer zonaId,
            @RequestParam DiaSemana dia,
            @RequestParam int hora) {
        
        NivelAfluencia nivel = heatmapService.obtenerAfluenciaHistorica(zonaId, dia, hora);
        return ResponseEntity.ok(nivel);
    }
}