package com.gocartacho.gocartacho.model;

public enum TipoNegocio {
    Restaurante,
    Bar,
    Tienda,
    Museo,
    Otro
}