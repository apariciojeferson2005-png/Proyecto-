package com.gocartacho.gocartacho.service;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.Ruta;
import java.util.List;

public interface RutaService {

    List<Ruta> obtenerTodasLasRutas();
    
    /**
     * Obtiene solo los comercios de una ruta, ordenados.
     */
    List<Comercio> obtenerComerciosPorRuta(Integer rutaId);
}