package com.gocartacho.gocartacho.model;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Set;
import java.util.List;

@Entity
@Table(name = "Zonas")
public class Zona implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "zona_id")
    private Integer zonaId;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "descripcion", columnDefinition = "TEXT")
    private String descripcion;

    // --- Relación Inversa con AfluenciaHistorica ---
    @OneToMany(mappedBy = "zona", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<AfluenciaHistorica> afluencias;

    // --- Relación con Comercios ---
    // Una Zona puede tener muchos Comercios
    @OneToMany(mappedBy = "zona", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Comercio> comercios;

    public Integer getZonaId() {
        return zonaId;
    }

    public void setZonaId(Integer zonaId) {
        this.zonaId = zonaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Set<Comercio> getComercios() {
        return comercios;
    }

    public void setComercios(Set<Comercio> comercios) {
        this.comercios = comercios;
    }

    public List<AfluenciaHistorica> getAfluencias() {
        return afluencias;
    }

    public void setAfluencias(List<AfluenciaHistorica> afluencias) {
        this.afluencias = afluencias;
    }
}