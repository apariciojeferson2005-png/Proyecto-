package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.Ruta;
import com.gocartacho.gocartacho.model.RutaComercio;
import com.gocartacho.gocartacho.repository.RutaComercioRepository;
import com.gocartacho.gocartacho.repository.RutaRepository;
import com.gocartacho.gocartacho.service.RutaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RutaServiceImpl implements RutaService {

    @Autowired
    private RutaRepository rutaRepository;

    @Autowired
    private RutaComercioRepository rutaComercioRepository;

    @Override
    public List<Ruta> obtenerTodasLasRutas() {
        return rutaRepository.findAll();
    }

    @Override
    public List<Comercio> obtenerComerciosPorRuta(Integer rutaId) {
        Ruta ruta = rutaRepository.findById(rutaId).orElse(null);
        if (ruta == null) {
            return Collections.emptyList();
        }

        // 1. Obtiene la lista de uniones (RutaComercio) ordenadas
        List<RutaComercio> unionesOrdenadas = rutaComercioRepository.findByRutaOrderByOrdenAsc(ruta);

        // 2. Transforma esa lista en una lista de Comercios
        return unionesOrdenadas.stream()
                .map(RutaComercio::getComercio)
                .collect(Collectors.toList());
    }
}