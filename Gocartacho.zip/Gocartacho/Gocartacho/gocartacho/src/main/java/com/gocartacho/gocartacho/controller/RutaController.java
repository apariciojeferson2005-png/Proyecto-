package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.Ruta;
import com.gocartacho.gocartacho.service.RutaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/rutas")
public class RutaController {

    @Autowired
    private RutaService rutaService;

    /**
     * Endpoint para obtener la lista de todas las rutas sugeridas.
     * URL: GET /api/v1/rutas
     */
    @GetMapping
    public ResponseEntity<List<Ruta>> obtenerTodasLasRutas() {
        return ResponseEntity.ok(rutaService.obtenerTodasLasRutas());
    }

    /**
     * Endpoint para obtener los comercios (ordenados) de una ruta específica.
     * URL: GET /api/v1/rutas/1/comercios
     */
    @GetMapping("/{rutaId}/comercios")
    public ResponseEntity<List<Comercio>> obtenerComerciosDeRuta(@PathVariable Integer rutaId) {
        List<Comercio> comercios = rutaService.obtenerComerciosPorRuta(rutaId);
        return ResponseEntity.ok(comercios);
    }
}