package com.gocartacho.gocartacho.service;

import com.gocartacho.gocartacho.model.Usuario;
import java.util.Optional;

public interface UsuarioService {

    /**
     * Registra un nuevo usuario, encriptando su contraseña.
     * Devuelve el usuario guardado o lanza una excepción si el email ya existe.
     */
    Usuario registrarUsuario(Usuario usuario) throws Exception;

    /**
     * Busca un usuario por su email (para login o validación).
     */
    Optional<Usuario> obtenerUsuarioPorEmail(String email);
}