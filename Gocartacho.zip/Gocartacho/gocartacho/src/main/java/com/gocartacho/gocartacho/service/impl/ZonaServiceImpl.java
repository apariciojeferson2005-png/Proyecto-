package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.model.Zona;
import com.gocartacho.gocartacho.repository.ZonaRepository;
import com.gocartacho.gocartacho.service.ZonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service // Le dice a Spring que esta clase es un Servicio
public class ZonaServiceImpl implements ZonaService {

    // Inyecta el repositorio que creamos antes
    @Autowired
    private ZonaRepository zonaRepository;

    @Override
    public List<Zona> obtenerTodasLasZonas() {
        return zonaRepository.findAll();
    }

    @Override
    public Zona obtenerZonaPorId(Integer id) {
        // findById devuelve un Optional, usamos orElse(null) para manejar si no lo encuentra
        return zonaRepository.findById(id).orElse(null);
    }

    @Override
    public Zona guardarZona(Zona zona) {
        return zonaRepository.save(zona);
    }

    @Override
    public void eliminarZona(Integer id) {
        zonaRepository.deleteById(id);
    }
}