package com.gocartacho.gocartacho.service;

import com.gocartacho.gocartacho.model.DiaSemana;
import com.gocartacho.gocartacho.model.NivelAfluencia;
import com.gocartacho.gocartacho.model.PuntoCalor;
import java.util.List;

public interface HeatmapService {

    /**
     * Guarda un nuevo ping de ubicación anónimo.
     */
    void guardarPuntoCalor(PuntoCalor puntoCalor);

    /**
     * Obtiene los pings recientes para el mapa de calor en tiempo real.
     * (Ej. últimos 15 minutos)
     */
    List<PuntoCalor> obtenerPuntosCalorTiempoReal();

    /**
     * Obtiene el nivel de afluencia promedio para el filtro histórico.
     */
    NivelAfluencia obtenerAfluenciaHistorica(Integer zonaId, DiaSemana dia, int hora);
}