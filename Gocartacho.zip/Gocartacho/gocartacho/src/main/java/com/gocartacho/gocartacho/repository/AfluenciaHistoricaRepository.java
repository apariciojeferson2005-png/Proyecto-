package com.gocartacho.gocartacho.repository;

import com.gocartacho.gocartacho.model.AfluenciaHistorica;
import com.gocartacho.gocartacho.model.DiaSemana;
import com.gocartacho.gocartacho.model.Zona;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface AfluenciaHistoricaRepository extends JpaRepository<AfluenciaHistorica, Long> {

    // Para el filtro: "¿Cuál es el nivel promedio de Getsemaní el viernes a las 8 PM?"
    Optional<AfluenciaHistorica> findByZonaAndDiaSemanaAndHora(Zona zona, DiaSemana diaSemana, int hora);
}