package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.model.*;
import com.gocartacho.gocartacho.repository.AfluenciaHistoricaRepository;
import com.gocartacho.gocartacho.repository.PuntoCalorRepository;
import com.gocartacho.gocartacho.repository.ZonaRepository;
import com.gocartacho.gocartacho.service.HeatmapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class HeatmapServiceImpl implements HeatmapService {

    @Autowired
    private PuntoCalorRepository puntoCalorRepository;

    @Autowired
    private AfluenciaHistoricaRepository afluenciaHistoricaRepository;

    @Autowired
    private ZonaRepository zonaRepository;

    // Define cuántos minutos hacia atrás se considera "tiempo real"
    private static final int MINUTOS_TIEMPO_REAL = 15;

    @Override
    public void guardarPuntoCalor(PuntoCalor puntoCalor) {
        // Añade la marca de tiempo antes de guardar
        puntoCalor.setTimestamp(LocalDateTime.now());
        puntoCalorRepository.save(puntoCalor);
    }

    // --- ¡ESTE MÉTODO FALTABA! ---
    @Override
    public List<PuntoCalor> obtenerPuntosCalorTiempoReal() {
        // Calcula el tiempo límite (ej. Ahora - 15 minutos)
        LocalDateTime tiempoLimite = LocalDateTime.now().minusMinutes(MINUTOS_TIEMPO_REAL);

        // Usa el método del repositorio que creamos
        return puntoCalorRepository.findByTimestampAfter(tiempoLimite);
    }

    // --- ¡ESTE MÉTODO TAMBIÉN FALTABA! ---
    @Override
    public NivelAfluencia obtenerAfluenciaHistorica(Integer zonaId, DiaSemana dia, int hora) {
        Optional<Zona> zona = zonaRepository.findById(zonaId);

        if (zona.isPresent()) {
            Optional<AfluenciaHistorica> historico = afluenciaHistoricaRepository
                    .findByZonaAndDiaSemanaAndHora(zona.get(), dia, hora);

            // Si encuentra un registro, devuelve el nivel. Si no, devuelve "Bajo" por
            // defecto.
            return historico.map(AfluenciaHistorica::getNivelPromedio).orElse(NivelAfluencia.Bajo);
        }

        return NivelAfluencia.Bajo; // Devuelve Bajo si la zona no existe
    }
}